# Bird Feed Calculator

This repository contains a collection of tools for formulating custom
seed mixes for cage and companion birds.  It includes:

* **pigeon‑mix‑web** – the original pigeon‑only web calculator.
* **pigeon‑mix‑web‑multi‑bird** – a multi‑species web calculator
  supporting pigeons, parrots, African greys, budgies, canaries and
  chickens.  Each species has tailored nutrition profiles,
  ingredient compatibility checks and safety warnings.
* **python‑package** – a command‑line utility for computing seed
  mixes, along with example test cases.
* **docs** – project summaries, user guides and research notes.

## Repository Structure

```
.
├── pigeon‑mix‑web‑multi‑bird/   # multi‑species web application
│   ├── client/                  # front‑end React/Vite code
│   ├── server/                  # optional API/server (placeholder)
│   └── package.json            # package configuration (CC‑BY‑NC‑4.0)
├── python‑package/             # Python CLI for seed mix calculation
│   └── pigeon_mix_calculator/  # package code and examples
├── docs/                       # guides and research
├── LICENSE                     # non‑commercial license text
└── README.md                   # this overview
```

## Running the Multi‑Bird Web App

1. Ensure you have **Node.js 18+** and **pnpm** (or npm/yarn) installed.
2. Navigate to `pigeon‑mix‑web‑multi‑bird` and install dependencies:

   ```bash
   pnpm install
   ```

3. Start the development server:

   ```bash
   pnpm dev
   ```

4. Open your browser to the port shown in the terminal (default
   <http://localhost:3000>).  Select a bird species from the top row to
   load species‑specific profiles, then add ingredients to see a
   calculated mix, nutrition summary and safety warnings.

For a production build, run `pnpm build` and start the server with
`pnpm start`.  See the detailed setup guide in `docs/` for more
information.

## License

The contents of this repository are licensed under the
**Creative Commons Attribution‑NonCommercial 4.0 International
License**.  You may use, share and adapt this material for
non‑commercial purposes, provided you give appropriate credit.  To
purchase a commercial licence, please contact the author.