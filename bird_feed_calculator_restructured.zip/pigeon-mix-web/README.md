# Pigeon Mix Web (Original)

This folder is reserved for the original pigeon‑only version of the
Seed Mix Calculator.  To keep the history intact, it can be
populated by extracting the contents of the original `pigeon-mix-web`
archive or repository.  The multi‑bird version lives in the sibling
directory `pigeon‑mix‑web‑multi‑bird`.

**Note:** The repository currently ships only the multi‑bird code.  If
you require the pigeon‑only implementation, please copy it into this
directory before building or publishing.